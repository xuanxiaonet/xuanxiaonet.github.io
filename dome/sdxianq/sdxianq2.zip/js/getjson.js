﻿// JavaScript Document
// 用JQuery解析获取JSON数据

$(function(){
	var url="";
	//使用getJSON方法取得JSON数据
	$.getJSON(　　　　
		url,
		//处理数据 data指向的是返回来的JSON数据
		function(data){
			
		}
	);
})